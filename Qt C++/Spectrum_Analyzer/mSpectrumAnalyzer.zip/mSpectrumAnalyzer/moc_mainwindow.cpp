/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[204];
    char stringdata0[11];
    char stringdata1[12];
    char stringdata2[1];
    char stringdata3[14];
    char stringdata4[6];
    char stringdata5[6];
    char stringdata6[13];
    char stringdata7[7];
    char stringdata8[14];
    char stringdata9[17];
    char stringdata10[17];
    char stringdata11[20];
    char stringdata12[24];
    char stringdata13[46];
    char stringdata14[6];
    char stringdata15[15];
    char stringdata16[15];
    char stringdata17[13];
    char stringdata18[20];
    char stringdata19[10];
    char stringdata20[9];
    char stringdata21[7];
    char stringdata22[14];
    char stringdata23[13];
    char stringdata24[13];
    char stringdata25[8];
    char stringdata26[15];
    char stringdata27[11];
    char stringdata28[7];
    char stringdata29[8];
    char stringdata30[8];
    char stringdata31[13];
    char stringdata32[11];
    char stringdata33[14];
    char stringdata34[18];
    char stringdata35[7];
    char stringdata36[7];
    char stringdata37[8];
    char stringdata38[14];
    char stringdata39[5];
    char stringdata40[9];
    char stringdata41[18];
    char stringdata42[22];
    char stringdata43[10];
    char stringdata44[9];
    char stringdata45[37];
    char stringdata46[25];
    char stringdata47[25];
    char stringdata48[25];
    char stringdata49[47];
    char stringdata50[36];
    char stringdata51[45];
    char stringdata52[27];
    char stringdata53[42];
    char stringdata54[5];
    char stringdata55[40];
    char stringdata56[19];
    char stringdata57[4];
    char stringdata58[23];
    char stringdata59[32];
    char stringdata60[31];
    char stringdata61[27];
    char stringdata62[26];
    char stringdata63[28];
    char stringdata64[28];
    char stringdata65[31];
    char stringdata66[6];
    char stringdata67[44];
    char stringdata68[36];
    char stringdata69[35];
    char stringdata70[46];
    char stringdata71[37];
    char stringdata72[38];
    char stringdata73[36];
    char stringdata74[44];
    char stringdata75[36];
    char stringdata76[15];
    char stringdata77[13];
    char stringdata78[13];
    char stringdata79[6];
    char stringdata80[57];
    char stringdata81[56];
    char stringdata82[24];
    char stringdata83[25];
    char stringdata84[34];
    char stringdata85[15];
    char stringdata86[31];
    char stringdata87[31];
    char stringdata88[24];
    char stringdata89[8];
    char stringdata90[40];
    char stringdata91[15];
    char stringdata92[17];
    char stringdata93[23];
    char stringdata94[19];
    char stringdata95[16];
    char stringdata96[3];
    char stringdata97[8];
    char stringdata98[13];
    char stringdata99[36];
    char stringdata100[33];
    char stringdata101[26];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 11),  // "onDataReady"
        QT_MOC_LITERAL(23, 0),  // ""
        QT_MOC_LITERAL(24, 13),  // "QList<double>"
        QT_MOC_LITERAL(38, 5),  // "dataI"
        QT_MOC_LITERAL(44, 5),  // "dataQ"
        QT_MOC_LITERAL(50, 12),  // "onUSRPstatus"
        QT_MOC_LITERAL(63, 6),  // "status"
        QT_MOC_LITERAL(70, 13),  // "deviceAddress"
        QT_MOC_LITERAL(84, 16),  // "onDockInitialize"
        QT_MOC_LITERAL(101, 16),  // "onPlotInitialize"
        QT_MOC_LITERAL(118, 19),  // "onSettingInitialize"
        QT_MOC_LITERAL(138, 23),  // "onSignalSlotsConnection"
        QT_MOC_LITERAL(162, 45),  // "on_comboBox_AntennaSingle_cur..."
        QT_MOC_LITERAL(208, 5),  // "index"
        QT_MOC_LITERAL(214, 14),  // "plotTimeDomain"
        QT_MOC_LITERAL(229, 14),  // "QList<double>&"
        QT_MOC_LITERAL(244, 12),  // "calcSpectrum"
        QT_MOC_LITERAL(257, 19),  // "avgFFToverTimeFrame"
        QT_MOC_LITERAL(277, 9),  // "fftavgRMS"
        QT_MOC_LITERAL(287, 8),  // "fftIndex"
        QT_MOC_LITERAL(296, 6),  // "fftVal"
        QT_MOC_LITERAL(303, 13),  // "fftIndexSweep"
        QT_MOC_LITERAL(317, 12),  // "fftMaxHoldDB"
        QT_MOC_LITERAL(330, 12),  // "fftMinHoldDB"
        QT_MOC_LITERAL(343, 7),  // "double&"
        QT_MOC_LITERAL(351, 14),  // "currentFreqMHz"
        QT_MOC_LITERAL(366, 10),  // "sweepArray"
        QT_MOC_LITERAL(377, 6),  // "avgRMS"
        QT_MOC_LITERAL(384, 7),  // "maxHold"
        QT_MOC_LITERAL(392, 7),  // "minHold"
        QT_MOC_LITERAL(400, 12),  // "plotSpectrum"
        QT_MOC_LITERAL(413, 10),  // "sweepIndex"
        QT_MOC_LITERAL(424, 13),  // "plotWaterfall"
        QT_MOC_LITERAL(438, 17),  // "plotConstellation"
        QT_MOC_LITERAL(456, 6),  // "constI"
        QT_MOC_LITERAL(463, 6),  // "constQ"
        QT_MOC_LITERAL(470, 7),  // "calcFFT"
        QT_MOC_LITERAL(478, 13),  // "calcAvgMaxMin"
        QT_MOC_LITERAL(492, 4),  // "int&"
        QT_MOC_LITERAL(497, 8),  // "sCounter"
        QT_MOC_LITERAL(506, 17),  // "sweepArrayFreqMHz"
        QT_MOC_LITERAL(524, 21),  // "QList<QList<double>>&"
        QT_MOC_LITERAL(546, 9),  // "avgMatrix"
        QT_MOC_LITERAL(556, 8),  // "avgIndex"
        QT_MOC_LITERAL(565, 36),  // "on_comboBox_nFFT_currentIndex..."
        QT_MOC_LITERAL(602, 24),  // "on_mouseDoubleClickPlot1"
        QT_MOC_LITERAL(627, 24),  // "on_mouseDoubleClickPlot2"
        QT_MOC_LITERAL(652, 24),  // "on_mouseDoubleClickPlot3"
        QT_MOC_LITERAL(677, 46),  // "on_doubleSpinBox_SampleRateMH..."
        QT_MOC_LITERAL(724, 35),  // "on_spinBox_mSamples_editingFi..."
        QT_MOC_LITERAL(760, 44),  // "on_doubleSpinBox_TimeFrameUS_..."
        QT_MOC_LITERAL(805, 26),  // "on_pushButton_Test_clicked"
        QT_MOC_LITERAL(832, 41),  // "on_comboBox_WindowType_curren..."
        QT_MOC_LITERAL(874, 4),  // "arg1"
        QT_MOC_LITERAL(879, 39),  // "on_comboBox_Gradient_currentT..."
        QT_MOC_LITERAL(919, 18),  // "contextMenuRequest"
        QT_MOC_LITERAL(938, 3),  // "pos"
        QT_MOC_LITERAL(942, 22),  // "showConstellationGraph"
        QT_MOC_LITERAL(965, 31),  // "on_actionFind_Devices_triggered"
        QT_MOC_LITERAL(997, 30),  // "on_actionStop_Device_triggered"
        QT_MOC_LITERAL(1028, 26),  // "on_actionAverage_triggered"
        QT_MOC_LITERAL(1055, 25),  // "on_actionSample_triggered"
        QT_MOC_LITERAL(1081, 27),  // "on_actionMax_Hold_triggered"
        QT_MOC_LITERAL(1109, 27),  // "on_actionMin_Hold_triggered"
        QT_MOC_LITERAL(1137, 30),  // "on_verticalSlider_valueChanged"
        QT_MOC_LITERAL(1168, 5),  // "value"
        QT_MOC_LITERAL(1174, 43),  // "on_doubleSpinBox_FreqSingleMH..."
        QT_MOC_LITERAL(1218, 35),  // "on_pushButton_SweepFullSpan_c..."
        QT_MOC_LITERAL(1254, 34),  // "on_pushButton_SpanWiFiBand_cl..."
        QT_MOC_LITERAL(1289, 45),  // "on_doubleSpinBox_SweepSpanMHz..."
        QT_MOC_LITERAL(1335, 36),  // "on_spinBox_GaindBsingle_value..."
        QT_MOC_LITERAL(1372, 37),  // "on_spinBox_WaterfallSize_valu..."
        QT_MOC_LITERAL(1410, 35),  // "on_spinBox_AverageSize_valueC..."
        QT_MOC_LITERAL(1446, 43),  // "on_doubleSpinBox_SampleRateMH..."
        QT_MOC_LITERAL(1490, 35),  // "on_actionReset_to_Default_tri..."
        QT_MOC_LITERAL(1526, 14),  // "removeRectItem"
        QT_MOC_LITERAL(1541, 12),  // "onMousePress"
        QT_MOC_LITERAL(1554, 12),  // "QMouseEvent*"
        QT_MOC_LITERAL(1567, 5),  // "event"
        QT_MOC_LITERAL(1573, 56),  // "on_doubleSpinBox_Constellatio..."
        QT_MOC_LITERAL(1630, 55),  // "on_doubleSpinBox_Constellatio..."
        QT_MOC_LITERAL(1686, 23),  // "updateConstellationRect"
        QT_MOC_LITERAL(1710, 24),  // "on_mouseDoubleClickPlot4"
        QT_MOC_LITERAL(1735, 33),  // "on_doubleSpinBox_RBW_valueCha..."
        QT_MOC_LITERAL(1769, 14),  // "onPauseDispley"
        QT_MOC_LITERAL(1784, 30),  // "on_spinBox_Index1_valueChanged"
        QT_MOC_LITERAL(1815, 30),  // "on_spinBox_Index2_valueChanged"
        QT_MOC_LITERAL(1846, 23),  // "on_checkBox_AGC_clicked"
        QT_MOC_LITERAL(1870, 7),  // "checked"
        QT_MOC_LITERAL(1878, 39),  // "on_comboBox_Channel_currentIn..."
        QT_MOC_LITERAL(1918, 14),  // "clearWaterfall"
        QT_MOC_LITERAL(1933, 16),  // "calcSweepIndices"
        QT_MOC_LITERAL(1950, 22),  // "updateSweepFrequencies"
        QT_MOC_LITERAL(1973, 18),  // "setUSRPsweepThread"
        QT_MOC_LITERAL(1992, 15),  // "resetCustomPlot"
        QT_MOC_LITERAL(2008, 2),  // "id"
        QT_MOC_LITERAL(2011, 7),  // "nGraphs"
        QT_MOC_LITERAL(2019, 12),  // "resetFilters"
        QT_MOC_LITERAL(2032, 35),  // "on_pushButton_SpanWiFiBand2_c..."
        QT_MOC_LITERAL(2068, 32),  // "on_pushButton__SpanBand3_clicked"
        QT_MOC_LITERAL(2101, 25)   // "on_checkBox_DCatt_clicked"
    },
    "MainWindow",
    "onDataReady",
    "",
    "QList<double>",
    "dataI",
    "dataQ",
    "onUSRPstatus",
    "status",
    "deviceAddress",
    "onDockInitialize",
    "onPlotInitialize",
    "onSettingInitialize",
    "onSignalSlotsConnection",
    "on_comboBox_AntennaSingle_currentIndexChanged",
    "index",
    "plotTimeDomain",
    "QList<double>&",
    "calcSpectrum",
    "avgFFToverTimeFrame",
    "fftavgRMS",
    "fftIndex",
    "fftVal",
    "fftIndexSweep",
    "fftMaxHoldDB",
    "fftMinHoldDB",
    "double&",
    "currentFreqMHz",
    "sweepArray",
    "avgRMS",
    "maxHold",
    "minHold",
    "plotSpectrum",
    "sweepIndex",
    "plotWaterfall",
    "plotConstellation",
    "constI",
    "constQ",
    "calcFFT",
    "calcAvgMaxMin",
    "int&",
    "sCounter",
    "sweepArrayFreqMHz",
    "QList<QList<double>>&",
    "avgMatrix",
    "avgIndex",
    "on_comboBox_nFFT_currentIndexChanged",
    "on_mouseDoubleClickPlot1",
    "on_mouseDoubleClickPlot2",
    "on_mouseDoubleClickPlot3",
    "on_doubleSpinBox_SampleRateMHz_editingFinished",
    "on_spinBox_mSamples_editingFinished",
    "on_doubleSpinBox_TimeFrameUS_editingFinished",
    "on_pushButton_Test_clicked",
    "on_comboBox_WindowType_currentTextChanged",
    "arg1",
    "on_comboBox_Gradient_currentTextChanged",
    "contextMenuRequest",
    "pos",
    "showConstellationGraph",
    "on_actionFind_Devices_triggered",
    "on_actionStop_Device_triggered",
    "on_actionAverage_triggered",
    "on_actionSample_triggered",
    "on_actionMax_Hold_triggered",
    "on_actionMin_Hold_triggered",
    "on_verticalSlider_valueChanged",
    "value",
    "on_doubleSpinBox_FreqSingleMHz_valueChanged",
    "on_pushButton_SweepFullSpan_clicked",
    "on_pushButton_SpanWiFiBand_clicked",
    "on_doubleSpinBox_SweepSpanMHz_editingFinished",
    "on_spinBox_GaindBsingle_valueChanged",
    "on_spinBox_WaterfallSize_valueChanged",
    "on_spinBox_AverageSize_valueChanged",
    "on_doubleSpinBox_SampleRateMHz_valueChanged",
    "on_actionReset_to_Default_triggered",
    "removeRectItem",
    "onMousePress",
    "QMouseEvent*",
    "event",
    "on_doubleSpinBox_ConstellationCenterFreqMHz_valueChanged",
    "on_doubleSpinBox_ConstellationBandwidthMHz_valueChanged",
    "updateConstellationRect",
    "on_mouseDoubleClickPlot4",
    "on_doubleSpinBox_RBW_valueChanged",
    "onPauseDispley",
    "on_spinBox_Index1_valueChanged",
    "on_spinBox_Index2_valueChanged",
    "on_checkBox_AGC_clicked",
    "checked",
    "on_comboBox_Channel_currentIndexChanged",
    "clearWaterfall",
    "calcSweepIndices",
    "updateSweepFrequencies",
    "setUSRPsweepThread",
    "resetCustomPlot",
    "id",
    "nGraphs",
    "resetFilters",
    "on_pushButton_SpanWiFiBand2_clicked",
    "on_pushButton__SpanBand3_clicked",
    "on_checkBox_DCatt_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      63,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,  392,    2, 0x08,    1 /* Private */,
       6,    2,  397,    2, 0x08,    4 /* Private */,
       9,    0,  402,    2, 0x08,    7 /* Private */,
      10,    0,  403,    2, 0x08,    8 /* Private */,
      11,    0,  404,    2, 0x08,    9 /* Private */,
      12,    0,  405,    2, 0x08,   10 /* Private */,
      13,    1,  406,    2, 0x08,   11 /* Private */,
      15,    2,  409,    2, 0x08,   13 /* Private */,
      17,   12,  414,    2, 0x08,   16 /* Private */,
      31,    6,  439,    2, 0x08,   29 /* Private */,
      33,    1,  452,    2, 0x08,   36 /* Private */,
      34,    2,  455,    2, 0x08,   38 /* Private */,
      37,    5,  460,    2, 0x08,   41 /* Private */,
      38,    8,  471,    2, 0x08,   47 /* Private */,
      45,    1,  488,    2, 0x08,   56 /* Private */,
      46,    0,  491,    2, 0x08,   58 /* Private */,
      47,    0,  492,    2, 0x08,   59 /* Private */,
      48,    0,  493,    2, 0x08,   60 /* Private */,
      49,    0,  494,    2, 0x08,   61 /* Private */,
      50,    0,  495,    2, 0x08,   62 /* Private */,
      51,    0,  496,    2, 0x08,   63 /* Private */,
      52,    0,  497,    2, 0x08,   64 /* Private */,
      53,    1,  498,    2, 0x08,   65 /* Private */,
      55,    1,  501,    2, 0x08,   67 /* Private */,
      56,    1,  504,    2, 0x08,   69 /* Private */,
      58,    0,  507,    2, 0x08,   71 /* Private */,
      59,    0,  508,    2, 0x08,   72 /* Private */,
      60,    0,  509,    2, 0x08,   73 /* Private */,
      61,    0,  510,    2, 0x08,   74 /* Private */,
      62,    0,  511,    2, 0x08,   75 /* Private */,
      63,    0,  512,    2, 0x08,   76 /* Private */,
      64,    0,  513,    2, 0x08,   77 /* Private */,
      65,    1,  514,    2, 0x08,   78 /* Private */,
      67,    1,  517,    2, 0x08,   80 /* Private */,
      68,    0,  520,    2, 0x08,   82 /* Private */,
      69,    0,  521,    2, 0x08,   83 /* Private */,
      70,    0,  522,    2, 0x08,   84 /* Private */,
      71,    1,  523,    2, 0x08,   85 /* Private */,
      72,    1,  526,    2, 0x08,   87 /* Private */,
      73,    1,  529,    2, 0x08,   89 /* Private */,
      74,    1,  532,    2, 0x08,   91 /* Private */,
      75,    0,  535,    2, 0x08,   93 /* Private */,
      76,    0,  536,    2, 0x08,   94 /* Private */,
      77,    1,  537,    2, 0x08,   95 /* Private */,
      80,    1,  540,    2, 0x08,   97 /* Private */,
      81,    1,  543,    2, 0x08,   99 /* Private */,
      82,    0,  546,    2, 0x08,  101 /* Private */,
      83,    0,  547,    2, 0x08,  102 /* Private */,
      84,    1,  548,    2, 0x08,  103 /* Private */,
      85,    0,  551,    2, 0x08,  105 /* Private */,
      86,    1,  552,    2, 0x08,  106 /* Private */,
      87,    1,  555,    2, 0x08,  108 /* Private */,
      88,    1,  558,    2, 0x08,  110 /* Private */,
      90,    1,  561,    2, 0x08,  112 /* Private */,
      91,    0,  564,    2, 0x08,  114 /* Private */,
      92,    0,  565,    2, 0x08,  115 /* Private */,
      93,    1,  566,    2, 0x08,  116 /* Private */,
      94,    1,  569,    2, 0x08,  118 /* Private */,
      95,    2,  572,    2, 0x08,  120 /* Private */,
      98,    0,  577,    2, 0x08,  123 /* Private */,
      99,    0,  578,    2, 0x08,  124 /* Private */,
     100,    0,  579,    2, 0x08,  125 /* Private */,
     101,    1,  580,    2, 0x08,  126 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3,    4,    5,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,    7,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 16,    4,    5,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 25, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16,   18,   19,   20,   21,   22,   23,   24,   26,   27,   28,   29,   30,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16,   20,   32,   21,   19,   23,   24,
    QMetaType::Void, 0x80000000 | 16,   19,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 16,   35,   36,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 16,    4,    5,   18,   35,   36,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 39, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 42, 0x80000000 | 16, 0x80000000 | 16, 0x80000000 | 39,   18,   40,   41,   28,   43,   29,   30,   44,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   54,
    QMetaType::Void, QMetaType::QString,   54,
    QMetaType::Void, QMetaType::QPoint,   57,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   66,
    QMetaType::Void, QMetaType::Double,   54,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   54,
    QMetaType::Void, QMetaType::Int,   54,
    QMetaType::Void, QMetaType::Int,   54,
    QMetaType::Void, QMetaType::Double,   54,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 78,   79,
    QMetaType::Void, QMetaType::Double,   54,
    QMetaType::Void, QMetaType::Double,   54,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,   54,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   54,
    QMetaType::Void, QMetaType::Int,   54,
    QMetaType::Void, QMetaType::Bool,   89,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,   54,
    QMetaType::Void, QMetaType::Double,   54,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   96,   97,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   89,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'onDataReady'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double>, std::false_type>,
        // method 'onUSRPstatus'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'onDockInitialize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onPlotInitialize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSettingInitialize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSignalSlotsConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_comboBox_AntennaSingle_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'plotTimeDomain'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        // method 'calcSpectrum'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<double &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        // method 'plotSpectrum'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        // method 'plotWaterfall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        // method 'plotConstellation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        // method 'calcFFT'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        // method 'calcAvgMaxMin'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<int &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<QVector<double>> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QVector<double> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<int &, std::false_type>,
        // method 'on_comboBox_nFFT_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_mouseDoubleClickPlot1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_mouseDoubleClickPlot2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_mouseDoubleClickPlot3'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_doubleSpinBox_SampleRateMHz_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_spinBox_mSamples_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_doubleSpinBox_TimeFrameUS_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_Test_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_comboBox_WindowType_currentTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_comboBox_Gradient_currentTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'contextMenuRequest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPoint, std::false_type>,
        // method 'showConstellationGraph'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionFind_Devices_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionStop_Device_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAverage_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionSample_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionMax_Hold_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionMin_Hold_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_verticalSlider_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_doubleSpinBox_FreqSingleMHz_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'on_pushButton_SweepFullSpan_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_SpanWiFiBand_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_doubleSpinBox_SweepSpanMHz_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_spinBox_GaindBsingle_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spinBox_WaterfallSize_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spinBox_AverageSize_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_doubleSpinBox_SampleRateMHz_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'on_actionReset_to_Default_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'removeRectItem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onMousePress'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QMouseEvent *, std::false_type>,
        // method 'on_doubleSpinBox_ConstellationCenterFreqMHz_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'on_doubleSpinBox_ConstellationBandwidthMHz_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'updateConstellationRect'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_mouseDoubleClickPlot4'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_doubleSpinBox_RBW_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'onPauseDispley'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_spinBox_Index1_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spinBox_Index2_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_checkBox_AGC_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_comboBox_Channel_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'clearWaterfall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'calcSweepIndices'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateSweepFrequencies'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'setUSRPsweepThread'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'resetCustomPlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'resetFilters'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_SpanWiFiBand2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton__SpanBand3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_checkBox_DCatt_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onDataReady((*reinterpret_cast< std::add_pointer_t<QList<double>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<double>>>(_a[2]))); break;
        case 1: _t->onUSRPstatus((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 2: _t->onDockInitialize(); break;
        case 3: _t->onPlotInitialize(); break;
        case 4: _t->onSettingInitialize(); break;
        case 5: _t->onSignalSlotsConnection(); break;
        case 6: _t->on_comboBox_AntennaSingle_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->plotTimeDomain((*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[2]))); break;
        case 8: _t->calcSpectrum((*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[7])),(*reinterpret_cast< std::add_pointer_t<double&>>(_a[8])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[9])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[10])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[11])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[12]))); break;
        case 9: _t->plotSpectrum((*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[6]))); break;
        case 10: _t->plotWaterfall((*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[1]))); break;
        case 11: _t->plotConstellation((*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[2]))); break;
        case 12: _t->calcFFT((*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[5]))); break;
        case 13: _t->calcAvgMaxMin((*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QList<QList<double>>&>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<QList<double>&>>(_a[7])),(*reinterpret_cast< std::add_pointer_t<int&>>(_a[8]))); break;
        case 14: _t->on_comboBox_nFFT_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 15: _t->on_mouseDoubleClickPlot1(); break;
        case 16: _t->on_mouseDoubleClickPlot2(); break;
        case 17: _t->on_mouseDoubleClickPlot3(); break;
        case 18: _t->on_doubleSpinBox_SampleRateMHz_editingFinished(); break;
        case 19: _t->on_spinBox_mSamples_editingFinished(); break;
        case 20: _t->on_doubleSpinBox_TimeFrameUS_editingFinished(); break;
        case 21: _t->on_pushButton_Test_clicked(); break;
        case 22: _t->on_comboBox_WindowType_currentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 23: _t->on_comboBox_Gradient_currentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 24: _t->contextMenuRequest((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 25: _t->showConstellationGraph(); break;
        case 26: _t->on_actionFind_Devices_triggered(); break;
        case 27: _t->on_actionStop_Device_triggered(); break;
        case 28: _t->on_actionAverage_triggered(); break;
        case 29: _t->on_actionSample_triggered(); break;
        case 30: _t->on_actionMax_Hold_triggered(); break;
        case 31: _t->on_actionMin_Hold_triggered(); break;
        case 32: _t->on_verticalSlider_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 33: _t->on_doubleSpinBox_FreqSingleMHz_valueChanged((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 34: _t->on_pushButton_SweepFullSpan_clicked(); break;
        case 35: _t->on_pushButton_SpanWiFiBand_clicked(); break;
        case 36: _t->on_doubleSpinBox_SweepSpanMHz_editingFinished(); break;
        case 37: _t->on_spinBox_GaindBsingle_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 38: _t->on_spinBox_WaterfallSize_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 39: _t->on_spinBox_AverageSize_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 40: _t->on_doubleSpinBox_SampleRateMHz_valueChanged((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 41: _t->on_actionReset_to_Default_triggered(); break;
        case 42: _t->removeRectItem(); break;
        case 43: _t->onMousePress((*reinterpret_cast< std::add_pointer_t<QMouseEvent*>>(_a[1]))); break;
        case 44: _t->on_doubleSpinBox_ConstellationCenterFreqMHz_valueChanged((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 45: _t->on_doubleSpinBox_ConstellationBandwidthMHz_valueChanged((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 46: _t->updateConstellationRect(); break;
        case 47: _t->on_mouseDoubleClickPlot4(); break;
        case 48: _t->on_doubleSpinBox_RBW_valueChanged((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 49: _t->onPauseDispley(); break;
        case 50: _t->on_spinBox_Index1_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 51: _t->on_spinBox_Index2_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 52: _t->on_checkBox_AGC_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 53: _t->on_comboBox_Channel_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 54: _t->clearWaterfall(); break;
        case 55: _t->calcSweepIndices(); break;
        case 56: _t->updateSweepFrequencies((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 57: _t->setUSRPsweepThread((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 58: _t->resetCustomPlot((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 59: _t->resetFilters(); break;
        case 60: _t->on_pushButton_SpanWiFiBand2_clicked(); break;
        case 61: _t->on_pushButton__SpanBand3_clicked(); break;
        case 62: _t->on_checkBox_DCatt_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<double> >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 63)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 63;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 63)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 63;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
